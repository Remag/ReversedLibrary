#pragma once

#include <Relib.h>

typedef CAARect<float> TAARect;
typedef CAARect<int> TIntAARect;

typedef CVector2<float> TVector2;
typedef CVector2<int> TIntVector2;

typedef CVector3<float> TVector3;
typedef CVector3<int> TIntVector3;

typedef CVector4<float> TVector4;
typedef CVector4<int> TIntVector4;

typedef CMatrix3<float> TMatrix3;
