#include <common.h>
#pragma hdrstop

int wmain( int argc, wchar_t** argv )
{
	argc, argv;
	return 0;
}